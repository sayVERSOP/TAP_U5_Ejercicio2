package com.example.tap_u5_ejercicio2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_main3.*

class MainActivity3 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)


        button.setOnClickListener {
            var texto1 = txt1.text.toString()
            var texto2= txt2.text.toString()
            var txtResultado = texto1+ " " +texto2

            textView.setText(txtResultado)
            txt1.setText(" ")
            txt2.setText(" ")
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {

        this.menuInflater.inflate(R.menu.menuoculto, menu)

        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.regresarmenu ->{
                var regre = Intent (this,MainActivity::class.java)
                startActivity(regre)
            }
            R.id.acercademenu ->{
               Toast.makeText(this,"(C) SERGIO BENIGNO", Toast.LENGTH_LONG)
                   .show()
            }
        }
        return super.onOptionsItemSelected(item)
    }
}