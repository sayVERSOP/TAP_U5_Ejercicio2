package com.example.tap_u5_ejercicio2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.android.synthetic.main.activity_main4.*
import java.io.OutputStreamWriter

class MainActivity4 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main4)

        btn1.setOnClickListener {


           if ( guardarEnmemoriaInterna(txt.text.toString()) == true){

               AlertDialog.Builder(this)
                   .setTitle("ALERTA")
                   .setMessage("SE GUARDO CON EXITO")
                   .setPositiveButton("Ok", {d,i -> d.dismiss()})
                   .show()
           }
        }

        btn2.setOnClickListener {
            finish()
        }
    }

    fun guardarEnmemoriaInterna(conten: String): Boolean {
        if (conten.isEmpty()) {
            Toast.makeText(this, "ERROR DEBES PONER UN ENUNCIADO A GUARDAR", Toast.LENGTH_LONG)
                .show()
            return false
        }

        try {


            var flujoSalida = OutputStreamWriter(openFileOutput("almacen.txt", MODE_PRIVATE))

            flujoSalida.write(conten)
            flujoSalida.flush()
            flujoSalida.close()

            return true

        } catch (io: Exception) {
            AlertDialog.Builder(this)
                .setTitle("ALERTA")
                .setMessage("NO SE PUDO GUARGAR EN ARCHIVO")
                .show()


        }
    return false
    }



}

