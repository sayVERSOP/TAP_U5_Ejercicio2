package com.example.tap_u5_ejercicio2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main2.*

class MainActivity2 : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main2)


        button3.setOnClickListener {
            var valor1 = num1.text.toString().toInt()
            var valor2 = num2.text.toString().toInt()
            var operacionCalcular = spinner.selectedItemPosition
            var resultado = 0

            when (operacionCalcular){

                0 -> { resultado = valor1+valor2 }
                1 -> {resultado = valor1-valor2}
                2 -> {resultado = valor1*valor2}
                3 -> {resultado = valor1/valor2}


            }
                AlertDialog.Builder(this)
                    .setTitle("RESULTADO")
                    .setMessage("Su Resultado Arrojo ${resultado}")
                    .setPositiveButton("Ok", {d,i ->d.dismiss()})
                    .show()
        }
        button4.setOnClickListener {
            var regre = Intent(this,MainActivity::class.java)
            startActivity(regre)
        }
    }
}