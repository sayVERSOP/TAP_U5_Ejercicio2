package com.example.tap_u5_ejercicio2

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.appcompat.app.AlertDialog
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        menuprincipal.setOnItemClickListener { parent, view, position, id ->

            when (position){
                0 -> {  var Ventana2 = Intent(this, MainActivity2::class.java)
                    startActivity(Ventana2)
                }
                1 -> {  var Ventana3 = Intent(this, MainActivity3::class.java)
                    startActivity(Ventana3)   }
                2 -> {   var Ventana4= Intent(this, MainActivity4::class.java)
                    startActivity(Ventana4)  }
                3 -> {    var Ventana5 = Intent(this, MainActivity5::class.java)
                    startActivity(Ventana5) }
                4 -> { mensaje() }
                5 -> { cerrar()  }


            }
        }

    }
    fun mensaje (  ){
        AlertDialog.Builder(this)
            .setTitle("ATENCION")
            .setMessage("(C) RECERVADOS SERGIO BENIGNO \nTeconologico De Tepic 2021")
            .setPositiveButton("ok", {d,i -> d.dismiss()})
            .show()
    }
    /* fun otroMetodo(  ) : Int {
         var retorno = 9
         return retorno
     }  */

    fun cerrar( ){
    finish()
    }
}